package com.buu.app.travel.role;



import com.baidu.mapapi.map.Polyline;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by bei on 2017/9/24.
 */

public class mColorfulPolylineint {
    Polyline mColorfulPolyline;
    int i;

    public mColorfulPolylineint(Polyline mColorfulPolyline, int i) {
        this.mColorfulPolyline = mColorfulPolyline;
        this.i = i;
    }

    public Polyline getmColorfulPolyline() {
        return mColorfulPolyline;
    }

    public void setmColorfulPolyline(Polyline mColorfulPolyline) {
        this.mColorfulPolyline = mColorfulPolyline;
    }

    public int getI() {
        return i;
    }

    public void setI(int i) {
        this.i = i;
    }
}
