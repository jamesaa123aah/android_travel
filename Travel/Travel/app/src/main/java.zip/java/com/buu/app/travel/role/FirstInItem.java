package com.buu.app.travel.role;

/**
 * Created by king- on 2017/8/3.
 */

public class FirstInItem {
    public int imageId;
    public FirstInItem(int imageId){
        this.imageId = imageId;
    }

}
